cmake_minimum_required(VERSION 3.22)

project(QtRoTcp LANGUAGES CXX)

add_subdirectory(server)
add_subdirectory(client)
