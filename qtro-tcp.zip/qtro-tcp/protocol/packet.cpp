#include "packet.h"

#include <QStringList>
#include <QtEndian>

namespace protocol {

QByteArray encode(const Packet &packet)
{
    QByteArray bytes(packetSize, Qt::Uninitialized);
    char *out = bytes.data();
    const auto writeWord = [&out](quint16 value) {
        qToBigEndian(value, out);
        out += 2;
    };

    writeWord(packet.req_word);
    writeWord(packet.resp_word);
    for (const auto word : packet.data)
        writeWord(word);
    return bytes;
}

std::optional<Packet> decode(QByteArrayView bytes)
{
    if (bytes.size() != packetSize)
        return std::nullopt;

    const char *in = bytes.data();
    const auto readWord = [&in] {
        const auto value = qFromBigEndian<quint16>(in);
        in += 2;
        return value;
    };

    Packet packet;
    packet.req_word = readWord();
    packet.resp_word = readWord();
    for (auto &word : packet.data)
        word = readWord();
    return packet;
}

QString describe(const Packet &packet)
{
    QStringList words;
    words.reserve(dataWordCount);
    for (const auto word : packet.data)
        words.append(QString::number(word));

    return QStringLiteral("req_word=%1  resp_word=%2  data=[%3]")
        .arg(packet.req_word)
        .arg(packet.resp_word)
        .arg(words.join(QStringLiteral(", ")));
}

} // namespace protocol
