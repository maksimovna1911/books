#pragma once

#include <QByteArray>
#include <QByteArrayView>
#include <QString>

#include <cstdint>
#include <optional>

namespace protocol {

inline constexpr int dataWordCount = 32;
inline constexpr int packetSize = (2 + dataWordCount) * 2;

struct Packet
{
    std::uint16_t req_word{};
    std::uint16_t resp_word{};
    std::uint16_t data[dataWordCount]{};
};

QByteArray encode(const Packet &packet);
std::optional<Packet> decode(QByteArrayView bytes);
QString describe(const Packet &packet);

} // namespace protocol
