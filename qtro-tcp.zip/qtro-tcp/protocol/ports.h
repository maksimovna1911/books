#pragma once

#include <QtTypes>

namespace protocol {

inline constexpr quint16 firstPort = 45451;
inline constexpr quint16 secondPort = 45452;

} // namespace protocol
