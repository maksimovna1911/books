#pragma once

#include <QWidget>

#include <memory>

namespace Ui {
class ServerWindow;
}

class ServerWindow final : public QWidget
{
    Q_OBJECT

public:
    explicit ServerWindow(QWidget *parent = nullptr);
    ~ServerWindow() override;

    void appendMessage(quint16 port, const QString &message);

private:
    std::unique_ptr<Ui::ServerWindow> m_ui;
};
