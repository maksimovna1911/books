#include "tcpendpoint.h"

#include <QHostAddress>
#include <QTcpSocket>
#include <QUrl>

TcpEndpoint::TcpEndpoint(quint16 port)
    : m_port(port)
{
    connect(&m_service, &PacketService::logMessage, this, &TcpEndpoint::writeLog);
    connect(&m_listener, &QTcpServer::newConnection, this, &TcpEndpoint::acceptConnections);
    connect(&m_listener, &QTcpServer::acceptError, this, [this] {
        writeLog(tr("Ошибка приёма TCP: %1").arg(m_listener.errorString()));
    });
}

void TcpEndpoint::listen(const QHostAddress &address)
{
    // The external URL identifies the QtRO host. QTcpServer opens the TCP port.
    const QUrl objectUrl(QStringLiteral("packet-tcp:/%1").arg(m_port));
    if (!m_host.setHostUrl(objectUrl, QRemoteObjectHost::AllowExternalRegistration)
        || !m_host.enableRemoting<PacketExchangeSourceAPI>(&m_service)) {
        writeLog(tr("Не удалось опубликовать PacketExchange (ошибка %1)")
                     .arg(int(m_host.lastError())));
        return;
    }

    if (!m_listener.listen(address, m_port)) {
        writeLog(tr("Не удалось открыть порт: %1").arg(m_listener.errorString()));
        return;
    }

    writeLog(tr("Слушаю [%1]:%2, объект PacketExchange").arg(address.toString()).arg(m_port));
}

void TcpEndpoint::acceptConnections()
{
    while (auto *socket = m_listener.nextPendingConnection()) {
        const QString peer = QStringLiteral("[%1]:%2")
                                 .arg(socket->peerAddress().toString()).arg(socket->peerPort());
        connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
        connect(socket, &QTcpSocket::disconnected, this, [this, peer] {
            writeLog(tr("TCP отключён %1").arg(peer));
        });

        writeLog(tr("TCP подключён %1").arg(peer));
        m_host.addHostSideConnection(socket);
    }
}

void TcpEndpoint::writeLog(const QString &message)
{
    emit logMessage(m_port, message);
}
