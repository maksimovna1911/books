#include "serverwindow.h"

#include "ui_serverwindow.h"

#include <QDateTime>
#include <QFontDatabase>

ServerWindow::ServerWindow(QWidget *parent)
    : QWidget(parent), m_ui(std::make_unique<Ui::ServerWindow>())
{
    m_ui->setupUi(this);
    m_ui->logEdit->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
}

ServerWindow::~ServerWindow() = default;

void ServerWindow::appendMessage(quint16 port, const QString &message)
{
    const QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss.zzz"));
    m_ui->logEdit->appendPlainText(QStringLiteral("%1  [%2]  %3").arg(time).arg(port).arg(message));
}
