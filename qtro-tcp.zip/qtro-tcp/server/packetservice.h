#pragma once

#include "rep_PacketExchange_source.h"

class PacketService final : public PacketExchangeSimpleSource
{
    Q_OBJECT

public:
    QByteArray exchange(QByteArray payload) override;

signals:
    void logMessage(const QString &message);
};
