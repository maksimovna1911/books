#include "ports.h"
#include "serverwindow.h"
#include "tcpendpoint.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QHostAddress>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("QtRoServer"));

    QCommandLineParser parser;
    parser.setApplicationDescription(QObject::tr("Двухпортовый TCP-сервер Qt Remote Objects"));
    parser.addHelpOption();
    const QCommandLineOption bindOption(QStringLiteral("bind"), QObject::tr("IP-адрес для прослушивания"),
                                        QStringLiteral("address"), QStringLiteral("127.0.0.1"));
    const QCommandLineOption port1Option(QStringLiteral("port1"), QObject::tr("Первый TCP-порт"),
                                         QStringLiteral("port"), QString::number(protocol::firstPort));
    const QCommandLineOption port2Option(QStringLiteral("port2"), QObject::tr("Второй TCP-порт"),
                                         QStringLiteral("port"), QString::number(protocol::secondPort));
    parser.addOptions({bindOption, port1Option, port2Option});
    parser.process(app);

    const QHostAddress address(parser.value(bindOption));
    bool port1Valid = false;
    bool port2Valid = false;
    const quint16 port1 = parser.value(port1Option).toUShort(&port1Valid);
    const quint16 port2 = parser.value(port2Option).toUShort(&port2Valid);
    if (address.isNull() || !port1Valid || !port2Valid || port1 == 0 || port2 == 0 || port1 == port2) {
        QMessageBox::critical(nullptr, QObject::tr("Ошибка параметров"),
                              QObject::tr("Укажите IP-адрес и два разных порта в диапазоне 1–65535."));
        return 1;
    }

    ServerWindow window;
    TcpEndpoint first(port1);
    TcpEndpoint second(port2);
    QObject::connect(&first, &TcpEndpoint::logMessage, &window, &ServerWindow::appendMessage);
    QObject::connect(&second, &TcpEndpoint::logMessage, &window, &ServerWindow::appendMessage);
    first.listen(address);
    second.listen(address);

    window.show();
    return app.exec();
}
