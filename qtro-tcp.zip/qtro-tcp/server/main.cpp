#include "packet.h"
#include "rep_PacketExchange_source.h"

#include <QApplication>
#include <QCommandLineParser>
#include <QDateTime>
#include <QFontDatabase>
#include <QHostAddress>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QTcpServer>
#include <QTcpSocket>
#include <QUrl>
#include <QVBoxLayout>

class PacketService final : public PacketExchangeSimpleSource
{
    Q_OBJECT

public:
    QByteArray exchange(QByteArray payload) override
    {
        auto packet = protocol::decode(payload);
        if (!packet) {
            emit logMessage(tr("Пакет отклонён: получено %1 байт, ожидалось %2")
                                .arg(payload.size()).arg(protocol::packetSize));
            return {};
        }

        emit logMessage(tr("RX %1").arg(protocol::describe(*packet)));
        packet->resp_word = packet->req_word;
        emit logMessage(tr("TX %1").arg(protocol::describe(*packet)));
        return protocol::encode(*packet);
    }

signals:
    void logMessage(const QString &message);
};

class TcpEndpoint final : public QObject
{
    Q_OBJECT

public:
    explicit TcpEndpoint(quint16 port) : m_port(port)
    {
        connect(&m_service, &PacketService::logMessage, this, &TcpEndpoint::logMessage);
        connect(&m_server, &QTcpServer::acceptError, this, [this] {
            emit logMessage(tr("Ошибка приёма TCP: %1").arg(m_server.errorString()));
        });
        connect(&m_server, &QTcpServer::newConnection, this, [this] {
            while (auto *socket = m_server.nextPendingConnection()) {
                const auto peer = QStringLiteral("[%1]:%2")
                                      .arg(socket->peerAddress().toString()).arg(socket->peerPort());
                emit logMessage(tr("TCP подключён %1").arg(peer));
                connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
                connect(socket, &QTcpSocket::disconnected, this, [this, peer] {
                    emit logMessage(tr("TCP отключён %1").arg(peer));
                });
                m_host.addHostSideConnection(socket);
            }
        });
    }

    void listen(const QHostAddress &address)
    {
        // QTcpServer owns the listener. The external URL identifies its QtRO source.
        const QUrl objectUrl(QStringLiteral("packet-tcp:/%1").arg(m_port));
        if (!m_host.setHostUrl(objectUrl, QRemoteObjectHost::AllowExternalRegistration)
            || !m_host.enableRemoting<PacketExchangeSourceAPI>(&m_service)) {
            emit logMessage(tr("Не удалось опубликовать PacketExchange (ошибка %1)")
                                .arg(int(m_host.lastError())));
            return;
        }
        if (!m_server.listen(address, m_port)) {
            emit logMessage(tr("Не удалось открыть порт: %1").arg(m_server.errorString()));
            return;
        }
        emit logMessage(tr("Слушаю [%1]:%2, объект PacketExchange").arg(address.toString()).arg(m_port));
    }

signals:
    void logMessage(const QString &message);

private:
    quint16 m_port;
    QTcpServer m_server;
    PacketService m_service;
    QRemoteObjectHost m_host;
};

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("QtRoServer"));

    QCommandLineParser parser;
    parser.setApplicationDescription(QObject::tr("Двухпортовый TCP-сервер Qt Remote Objects"));
    parser.addHelpOption();
    const QCommandLineOption bindOption(QStringLiteral("bind"), QObject::tr("IP-адрес для прослушивания"),
                                        QStringLiteral("address"), QStringLiteral("127.0.0.1"));
    const QCommandLineOption port1Option(QStringLiteral("port1"), QObject::tr("Первый TCP-порт"),
                                         QStringLiteral("port"), QString::number(protocol::firstPort));
    const QCommandLineOption port2Option(QStringLiteral("port2"), QObject::tr("Второй TCP-порт"),
                                         QStringLiteral("port"), QString::number(protocol::secondPort));
    parser.addOptions({bindOption, port1Option, port2Option});
    parser.process(app);

    const QHostAddress address(parser.value(bindOption));
    bool port1Valid = false;
    bool port2Valid = false;
    const quint16 port1 = parser.value(port1Option).toUShort(&port1Valid);
    const quint16 port2 = parser.value(port2Option).toUShort(&port2Valid);
    if (address.isNull() || !port1Valid || !port2Valid || port1 == 0 || port2 == 0 || port1 == port2) {
        QMessageBox::critical(nullptr, QObject::tr("Ошибка параметров"),
                              QObject::tr("Укажите IP-адрес и два разных порта в диапазоне 1–65535."));
        return 1;
    }

    QWidget window;
    window.setWindowTitle(QObject::tr("Qt Remote Objects — серверный журнал"));
    auto *layout = new QVBoxLayout(&window);
    auto *log = new QPlainTextEdit(&window);
    log->setReadOnly(true);
    log->setMaximumBlockCount(2000);
    log->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    log->setStyleSheet(QStringLiteral("QPlainTextEdit { background: #111827; color: #e5e7eb; }"));
    layout->addWidget(log);
    window.resize(950, 480);

    const auto append = [log](quint16 port, const QString &message) {
        const auto time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss.zzz"));
        log->appendPlainText(QStringLiteral("%1  [%2]  %3").arg(time).arg(port).arg(message));
    };
    TcpEndpoint first(port1);
    TcpEndpoint second(port2);
    QObject::connect(&first, &TcpEndpoint::logMessage, log,
                     [append, port1](const QString &message) { append(port1, message); });
    QObject::connect(&second, &TcpEndpoint::logMessage, log,
                     [append, port2](const QString &message) { append(port2, message); });
    first.listen(address);
    second.listen(address);

    window.show();
    return app.exec();
}

#include "main.moc"
