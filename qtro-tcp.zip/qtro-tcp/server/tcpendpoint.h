#pragma once

#include "packetservice.h"

#include <QRemoteObjectHost>
#include <QTcpServer>

class TcpEndpoint final : public QObject
{
    Q_OBJECT

public:
    explicit TcpEndpoint(quint16 port);
    void listen(const QHostAddress &address);

signals:
    void logMessage(quint16 port, const QString &message);

private:
    void acceptConnections();
    void writeLog(const QString &message);

    quint16 m_port;
    QTcpServer m_listener;
    PacketService m_service;
    QRemoteObjectHost m_host;
};
