cmake_minimum_required(VERSION 3.22)

project(QtRoServer LANGUAGES CXX)

find_package(Qt6 6.10 REQUIRED COMPONENTS Widgets Network RemoteObjects)
qt_standard_project_setup()

qt_add_executable(QtRoServer WIN32
    main.cpp
    serverwindow.cpp serverwindow.h serverwindow.ui
    tcpendpoint.cpp tcpendpoint.h
    packetservice.cpp packetservice.h
    ../protocol/packet.cpp ../protocol/packet.h
    ../protocol/ports.h
)
set_target_properties(QtRoServer PROPERTIES
    CXX_STANDARD 23
    CXX_STANDARD_REQUIRED ON
    CXX_EXTENSIONS OFF
)
target_include_directories(QtRoServer PRIVATE ../protocol "${CMAKE_CURRENT_BINARY_DIR}")
target_link_libraries(QtRoServer PRIVATE Qt6::Widgets Qt6::Network Qt6::RemoteObjects)
qt_add_repc_sources(QtRoServer ../protocol/PacketExchange.rep)
