#include "packetservice.h"

#include "packet.h"

QByteArray PacketService::exchange(QByteArray payload)
{
    auto packet = protocol::decode(payload);
    if (!packet) {
        emit logMessage(tr("Пакет отклонён: получено %1 байт, ожидалось %2")
                            .arg(payload.size()).arg(protocol::packetSize));
        return {};
    }

    emit logMessage(tr("RX %1").arg(protocol::describe(*packet)));
    packet->resp_word = packet->req_word;
    emit logMessage(tr("TX %1").arg(protocol::describe(*packet)));
    return protocol::encode(*packet);
}
