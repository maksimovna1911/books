#pragma once

#include "packet.h"

#include <QObject>
#include <QTimer>

class QRemoteObjectPendingCallWatcher;

class ClientConnection final : public QObject
{
    Q_OBJECT

public:
    explicit ClientConnection(QObject *parent = nullptr);
    ~ClientConnection() override;

    void start(const QString &host, quint16 port);
    void stop();
    void setAutoReconnect(bool enabled);
    void send(const protocol::Packet &packet);

    bool isActive() const;
    bool canSend() const;
    QString status() const;
    QString connectionDetails() const;

signals:
    void changed();
    void logMessage(const QString &message);
    void packetSent(const protocol::Packet &packet);
    void packetReceived(const protocol::Packet &packet);

private:
    struct Session;

    void connectTcp();
    void closeSession();
    void disconnectSession(const QString &reason);
    void fail(const QString &reason);
    void finishReply(QRemoteObjectPendingCallWatcher *reply);
    void setStatus(const QString &status);

    Session *m_session = nullptr;
    QRemoteObjectPendingCallWatcher *m_pending = nullptr;
    QString m_host;
    quint16 m_port = 0;
    QString m_status;
    bool m_autoReconnect = true;
    QTimer m_retryTimer;
    QTimer m_connectTimer;
    QTimer m_replyTimer;
};
