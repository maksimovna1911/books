#include "clientwindow.h"

#include "ports.h"
#include "ui_clientwindow.h"

ClientWindow::ClientWindow(QWidget *parent)
    : QWidget(parent), m_ui(std::make_unique<Ui::ClientWindow>())
{
    m_ui->setupUi(this);
    m_ui->firstClientPanel->setPort(protocol::firstPort);
    m_ui->secondClientPanel->setPort(protocol::secondPort);
}

ClientWindow::~ClientWindow() = default;

void ClientWindow::connectClients()
{
    m_ui->firstClientPanel->start();
    m_ui->secondClientPanel->start();
}
