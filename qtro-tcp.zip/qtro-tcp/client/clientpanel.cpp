#include "clientpanel.h"
#include "rep_PacketExchange_replica.h"

#include <QCheckBox>
#include <QDateTime>
#include <QFontDatabase>
#include <QFormLayout>
#include <QHostAddress>
#include <QLabel>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QTcpSocket>
#include <QVBoxLayout>

#include <memory>

namespace {

constexpr int retryIntervalMs = 2000;
constexpr int connectionTimeoutMs = 5000;
constexpr int replyTimeoutMs = 5000;

QSpinBox *wordEditor(QWidget *parent)
{
    auto *editor = new QSpinBox(parent);
    editor->setRange(0, 65535);
    return editor;
}

} // namespace

struct ClientPanel::Connection : QObject
{
    explicit Connection(QObject *parent) : QObject(parent), replica(node.acquire<PacketExchangeReplica>()) {}

    QTcpSocket socket;
    QRemoteObjectNode node;
    std::unique_ptr<PacketExchangeReplica> replica;
};

ClientPanel::ClientPanel(const QString &title, quint16 port, QWidget *parent)
    : QGroupBox(title, parent),
      m_host(new QLineEdit(QStringLiteral("127.0.0.1"), this)),
      m_port(wordEditor(this)),
      m_autoReconnect(new QCheckBox(tr("Автопереподключение"), this)),
      m_connectButton(new QPushButton(this)),
      m_status(new QLabel(tr("Отключён"), this)),
      m_endpoints(new QLabel(this)),
      m_reqWord(wordEditor(this)),
      m_respWord(wordEditor(this)),
      m_sendButton(new QPushButton(tr("Отправить пакет"), this)),
      m_log(new QPlainTextEdit(this))
{
    m_port->setMinimum(1);
    m_port->setValue(port);
    m_autoReconnect->setChecked(true);
    m_status->setWordWrap(true);
    m_status->setTextFormat(Qt::PlainText);
    m_endpoints->setWordWrap(true);
    m_endpoints->setTextInteractionFlags(Qt::TextSelectableByMouse);
    m_endpoints->hide();
    m_log->setReadOnly(true);
    m_log->setMaximumBlockCount(250);
    m_log->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    m_log->setMinimumHeight(130);

    auto *layout = new QVBoxLayout(this);
    auto *connectionForm = new QFormLayout;
    connectionForm->addRow(tr("Адрес сервера"), m_host);
    connectionForm->addRow(tr("TCP-порт"), m_port);
    layout->addLayout(connectionForm);

    auto *connectionActions = new QHBoxLayout;
    connectionActions->addWidget(m_connectButton);
    connectionActions->addWidget(m_autoReconnect);
    connectionActions->addStretch();
    layout->addLayout(connectionActions);
    layout->addWidget(m_status);
    layout->addWidget(m_endpoints);

    auto *packetGroup = new QGroupBox(tr("Пакет запроса"), this);
    auto *packetLayout = new QVBoxLayout(packetGroup);
    auto *words = new QFormLayout;
    words->addRow(QStringLiteral("req_word"), m_reqWord);
    words->addRow(QStringLiteral("resp_word"), m_respWord);
    packetLayout->addLayout(words);
    auto *dataGrid = new QGridLayout;
    for (int i = 0; i < protocol::dataWordCount; ++i) {
        auto *editor = wordEditor(packetGroup);
        m_data[i] = editor;
        const QString fieldName = QStringLiteral("data[%1]").arg(i);
        editor->setAccessibleName(fieldName);
        editor->setToolTip(fieldName);
        auto *label = new QLabel(QString::number(i), packetGroup);
        label->setBuddy(editor);
        const int row = i / 4;
        const int column = (i % 4) * 2;
        dataGrid->addWidget(label, row, column);
        dataGrid->addWidget(editor, row, column + 1);
        dataGrid->setColumnStretch(column + 1, 1);
    }
    packetLayout->addWidget(new QLabel(QStringLiteral("data[32]"), packetGroup));
    packetLayout->addLayout(dataGrid);
    layout->addWidget(packetGroup);
    layout->addWidget(m_sendButton);
    layout->addWidget(new QLabel(tr("Обмен и состояние подключения"), this));
    layout->addWidget(m_log, 1);

    m_retryTimer.setSingleShot(true);
    m_retryTimer.setInterval(retryIntervalMs);
    connect(&m_retryTimer, &QTimer::timeout, this, &ClientPanel::connectTcp);

    m_connectionTimer.setSingleShot(true);
    m_connectionTimer.setInterval(connectionTimeoutMs);
    connect(&m_connectionTimer, &QTimer::timeout, this, [this] {
        connectionFailed(tr("Тайм-аут подключения TCP / Qt Remote Objects"));
    });

    m_replyTimer.setSingleShot(true);
    m_replyTimer.setInterval(replyTimeoutMs);
    connect(&m_replyTimer, &QTimer::timeout, this, [this] {
        connectionFailed(tr("Тайм-аут ответа"));
    });

    connect(m_connectButton, &QPushButton::clicked, this, [this] {
        if (!m_running) {
            start();
            return;
        }
        m_running = false;
        m_retryTimer.stop();
        closeConnection();
        m_status->setText(tr("Отключён вручную"));
        appendLog(m_status->text());
        updateControls();
    });
    connect(m_autoReconnect, &QCheckBox::toggled, this, [this](bool enabled) {
        if (!enabled && m_retryTimer.isActive()) {
            m_retryTimer.stop();
            m_running = false;
            m_status->setText(tr("Отключён"));
            updateControls();
        }
    });
    connect(m_sendButton, &QPushButton::clicked, this, &ClientPanel::sendPacket);
    updateControls();
}

ClientPanel::~ClientPanel()
{
    closeConnection();
}

void ClientPanel::start()
{
    if (m_running)
        return;
    if (m_host->text().trimmed().isEmpty()) {
        m_status->setText(tr("Введите адрес сервера"));
        m_host->setFocus();
        return;
    }
    m_running = true;
    connectTcp();
}

void ClientPanel::connectTcp()
{
    auto *connection = new Connection(this);
    m_connection = connection;
    auto *socket = &connection->socket;
    const QString host = m_host->text().trimmed();
    const auto port = quint16(m_port->value());

    connect(socket, &QTcpSocket::connected, this, [this, connection, socket] {
        socket->setSocketOption(QAbstractSocket::KeepAliveOption, 1);
        m_endpoints->setText(tr("Локально [%1]:%2 → сервер [%3]:%4")
                                 .arg(socket->localAddress().toString()).arg(socket->localPort())
                                 .arg(socket->peerAddress().toString()).arg(socket->peerPort()));
        m_endpoints->show();
        m_status->setText(tr("TCP подключён. Инициализация Qt Remote Objects…"));
        connection->node.addClientSideConnection(socket);
    });
    connect(socket, &QTcpSocket::errorOccurred, this, [this, socket] {
        connectionFailed(tr("Ошибка TCP: %1").arg(socket->errorString()));
    });
    connect(socket, &QTcpSocket::disconnected, this, [this] {
        connectionFailed(tr("Соединение TCP закрыто"));
    });
    connect(connection->replica.get(), &QRemoteObjectReplica::stateChanged, this,
            [this](QRemoteObjectReplica::State state, QRemoteObjectReplica::State previous) {
                if (state == QRemoteObjectReplica::Valid) {
                    m_connectionTimer.stop();
                    m_status->setText(tr("Подключён · PacketExchange готов"));
                    appendLog(m_endpoints->text());
                } else if (state == QRemoteObjectReplica::SignatureMismatch) {
                    connectionFailed(tr("Интерфейс PacketExchange не совпадает с сервером"));
                } else if (previous == QRemoteObjectReplica::Valid) {
                    connectionFailed(tr("Объект PacketExchange больше недоступен"));
                }
                updateControls();
            });

    m_status->setText(tr("Подключение к [%1]:%2…").arg(host).arg(port));
    updateControls();
    m_connectionTimer.start();
    socket->connectToHost(host, port);
}

void ClientPanel::closeConnection()
{
    m_connectionTimer.stop();
    m_replyTimer.stop();
    if (!m_connection)
        return;

    if (m_pending) {
        disconnect(m_pending, nullptr, this, nullptr);
        m_pending = nullptr;
        appendLog(tr("Ответ на отправленный пакет не получен"));
    }
    auto *connection = m_connection;
    m_connection = nullptr;
    disconnect(&connection->socket, nullptr, this, nullptr);
    disconnect(connection->replica.get(), nullptr, this, nullptr);
    connection->socket.abort();
    connection->deleteLater();
    m_endpoints->clear();
    m_endpoints->hide();
}

void ClientPanel::connectionFailed(const QString &reason)
{
    closeConnection();
    appendLog(reason);
    if (m_autoReconnect->isChecked()) {
        m_status->setText(tr("%1. Повтор через %2 с").arg(reason).arg(retryIntervalMs / 1000));
        m_retryTimer.start();
    } else {
        m_running = false;
        m_status->setText(reason);
    }
    updateControls();
}

void ClientPanel::sendPacket()
{
    if (!m_connection || !m_connection->replica->isReplicaValid() || m_pending)
        return;

    protocol::Packet packet;
    packet.req_word = quint16(m_reqWord->value());
    packet.resp_word = quint16(m_respWord->value());
    for (int i = 0; i < protocol::dataWordCount; ++i)
        packet.data[i] = quint16(m_data[i]->value());

    const auto call = m_connection->replica->exchange(protocol::encode(packet));
    auto *watcher = new QRemoteObjectPendingCallWatcher(call, m_connection);
    m_pending = watcher;
    connect(watcher, &QRemoteObjectPendingCallWatcher::finished, this, [this, call, watcher] {
        m_pending = nullptr;
        m_replyTimer.stop();
        watcher->deleteLater();
        if (call.error() != QRemoteObjectPendingCall::NoError) {
            appendLog(tr("Ошибка удалённого вызова (код %1)").arg(int(call.error())));
        } else if (const auto packet = protocol::decode(call.returnValue())) {
            appendLog(tr("RX %1").arg(protocol::describe(*packet)));
        } else {
            appendLog(tr("Сервер вернул пакет неверной длины"));
        }
        updateControls();
    });
    appendLog(tr("TX %1").arg(protocol::describe(packet)));
    m_replyTimer.start();
    updateControls();
}

void ClientPanel::updateControls()
{
    m_host->setEnabled(!m_running);
    m_port->setEnabled(!m_running);
    m_connectButton->setText(m_running ? tr("Отключить") : tr("Подключить"));
    m_sendButton->setEnabled(m_connection && m_connection->replica->isReplicaValid() && !m_pending);
}

void ClientPanel::appendLog(const QString &message)
{
    const QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss.zzz"));
    m_log->appendPlainText(QStringLiteral("%1  %2").arg(time, message));
}
