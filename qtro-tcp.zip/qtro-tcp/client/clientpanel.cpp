#include "clientpanel.h"

#include "ui_clientpanel.h"

#include <QDateTime>
#include <QFontDatabase>

ClientPanel::ClientPanel(QWidget *parent)
    : QGroupBox(parent), m_ui(std::make_unique<Ui::ClientPanel>())
{
    m_ui->setupUi(this);
    m_ui->logEdit->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    m_connection.setAutoReconnect(m_ui->autoReconnectCheckBox->isChecked());

    connect(m_ui->connectButton, &QPushButton::clicked, this, [this] {
        if (m_connection.isActive())
            m_connection.stop();
        else
            start();
    });
    connect(m_ui->autoReconnectCheckBox, &QCheckBox::toggled,
            &m_connection, &ClientConnection::setAutoReconnect);
    connect(m_ui->sendButton, &QPushButton::clicked, this, [this] {
        m_connection.send(m_ui->packetEditor->packet());
    });
    connect(&m_connection, &ClientConnection::changed, this, &ClientPanel::refresh);
    connect(&m_connection, &ClientConnection::logMessage, this, &ClientPanel::appendLog);
    connect(&m_connection, &ClientConnection::packetSent, this, [this](const protocol::Packet &packet) {
        appendLog(tr("TX %1").arg(protocol::describe(packet)));
    });
    connect(&m_connection, &ClientConnection::packetReceived, this, [this](const protocol::Packet &packet) {
        appendLog(tr("RX %1").arg(protocol::describe(packet)));
    });

    refresh();
}

ClientPanel::~ClientPanel() = default;

void ClientPanel::setPort(quint16 port)
{
    m_ui->portSpinBox->setValue(port);
}

void ClientPanel::start()
{
    const QString address = m_ui->hostEdit->text().trimmed();
    m_connection.start(address, static_cast<quint16>(m_ui->portSpinBox->value()));
    if (address.isEmpty())
        m_ui->hostEdit->setFocus();
}

void ClientPanel::refresh()
{
    const bool active = m_connection.isActive();
    const QString details = m_connection.connectionDetails();
    m_ui->hostEdit->setEnabled(!active);
    m_ui->portSpinBox->setEnabled(!active);
    m_ui->connectButton->setText(active ? tr("Отключить") : tr("Подключить"));
    m_ui->statusLabel->setText(m_connection.status());
    m_ui->endpointsLabel->setText(details);
    m_ui->endpointsLabel->setVisible(!details.isEmpty());
    m_ui->sendButton->setEnabled(m_connection.canSend());
}

void ClientPanel::appendLog(const QString &message)
{
    const QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss.zzz"));
    m_ui->logEdit->appendPlainText(QStringLiteral("%1  %2").arg(time, message));
}
