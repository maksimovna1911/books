#include "packeteditor.h"

#include "ui_packeteditor.h"

#include <array>

PacketEditor::PacketEditor(QWidget *parent)
    : QGroupBox(parent), m_ui(std::make_unique<Ui::PacketEditor>())
{
    m_ui->setupUi(this);
}

PacketEditor::~PacketEditor() = default;

protocol::Packet PacketEditor::packet() const
{
    const std::array dataEditors{
        m_ui->data00, m_ui->data01, m_ui->data02, m_ui->data03,
        m_ui->data04, m_ui->data05, m_ui->data06, m_ui->data07,
        m_ui->data08, m_ui->data09, m_ui->data10, m_ui->data11,
        m_ui->data12, m_ui->data13, m_ui->data14, m_ui->data15,
        m_ui->data16, m_ui->data17, m_ui->data18, m_ui->data19,
        m_ui->data20, m_ui->data21, m_ui->data22, m_ui->data23,
        m_ui->data24, m_ui->data25, m_ui->data26, m_ui->data27,
        m_ui->data28, m_ui->data29, m_ui->data30, m_ui->data31,
    };
    static_assert(std::tuple_size_v<decltype(dataEditors)> == protocol::dataWordCount);

    protocol::Packet packet;
    packet.req_word = static_cast<std::uint16_t>(m_ui->requestWordSpinBox->value());
    packet.resp_word = static_cast<std::uint16_t>(m_ui->responseWordSpinBox->value());
    for (std::size_t index = 0; index < dataEditors.size(); ++index)
        packet.data[index] = static_cast<std::uint16_t>(dataEditors[index]->value());
    return packet;
}
