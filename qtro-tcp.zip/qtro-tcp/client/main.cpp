#include "clientpanel.h"

#include <QApplication>
#include <QHBoxLayout>
#include <QScrollArea>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("QtRoClient"));

    QScrollArea window;
    window.setWindowTitle(QObject::tr("Qt Remote Objects — два TCP-клиента"));
    window.setWidgetResizable(true);
    auto *content = new QWidget;
    auto *layout = new QHBoxLayout(content);
    auto *first = new ClientPanel(QObject::tr("Клиент 1"), protocol::firstPort, content);
    auto *second = new ClientPanel(QObject::tr("Клиент 2"), protocol::secondPort, content);
    layout->addWidget(first, 1);
    layout->addWidget(second, 1);
    window.setWidget(content);
    window.resize(1120, 740);
    window.show();

    first->start();
    second->start();
    return app.exec();
}
