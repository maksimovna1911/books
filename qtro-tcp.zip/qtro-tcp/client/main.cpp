#include "clientwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("QtRoClient"));

    ClientWindow window;
    window.show();
    window.connectClients();
    return app.exec();
}
