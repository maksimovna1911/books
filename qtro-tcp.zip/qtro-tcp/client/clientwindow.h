#pragma once

#include <QWidget>

#include <memory>

namespace Ui {
class ClientWindow;
}

class ClientWindow final : public QWidget
{
    Q_OBJECT

public:
    explicit ClientWindow(QWidget *parent = nullptr);
    ~ClientWindow() override;

    void connectClients();

private:
    std::unique_ptr<Ui::ClientWindow> m_ui;
};
