#include "clientconnection.h"

#include "rep_PacketExchange_replica.h"

#include <QHostAddress>
#include <QRemoteObjectNode>
#include <QRemoteObjectPendingCall>
#include <QTcpSocket>

#include <memory>

namespace {

constexpr int retryIntervalMs = 2000;
constexpr int connectTimeoutMs = 5000;
constexpr int replyTimeoutMs = 5000;

} // namespace

struct ClientConnection::Session : QObject
{
    explicit Session(QObject *parent)
        : QObject(parent), replica(node.acquire<PacketExchangeReplica>())
    {
    }

    QTcpSocket socket;
    QRemoteObjectNode node;
    std::unique_ptr<PacketExchangeReplica> replica;
};

ClientConnection::ClientConnection(QObject *parent)
    : QObject(parent), m_status(tr("Отключён"))
{
    m_retryTimer.setSingleShot(true);
    m_retryTimer.setInterval(retryIntervalMs);
    connect(&m_retryTimer, &QTimer::timeout, this, &ClientConnection::connectTcp);

    m_connectTimer.setSingleShot(true);
    m_connectTimer.setInterval(connectTimeoutMs);
    connect(&m_connectTimer, &QTimer::timeout, this, [this] {
        fail(tr("Тайм-аут подключения TCP / Qt Remote Objects"));
    });

    m_replyTimer.setSingleShot(true);
    m_replyTimer.setInterval(replyTimeoutMs);
    connect(&m_replyTimer, &QTimer::timeout, this, [this] {
        fail(tr("Тайм-аут ответа"));
    });
}

ClientConnection::~ClientConnection()
{
    closeSession();
}

void ClientConnection::start(const QString &host, quint16 port)
{
    if (isActive())
        return;

    const QString address = host.trimmed();
    if (address.isEmpty() || port == 0) {
        setStatus(tr("Укажите адрес сервера и TCP-порт"));
        return;
    }

    m_host = address;
    m_port = port;
    connectTcp();
}

void ClientConnection::stop()
{
    m_retryTimer.stop();
    disconnectSession(tr("Отключён вручную"));
}

void ClientConnection::setAutoReconnect(bool enabled)
{
    m_autoReconnect = enabled;
    if (!enabled && m_retryTimer.isActive()) {
        m_retryTimer.stop();
        setStatus(tr("Отключён"));
    }
}

bool ClientConnection::isActive() const
{
    return m_session || m_retryTimer.isActive();
}

bool ClientConnection::canSend() const
{
    return m_session && m_session->replica->isReplicaValid() && !m_pending;
}

QString ClientConnection::status() const
{
    return m_status;
}

QString ClientConnection::connectionDetails() const
{
    if (!m_session || m_session->socket.state() != QAbstractSocket::ConnectedState)
        return {};

    const auto &socket = m_session->socket;
    return tr("Локально [%1]:%2 → сервер [%3]:%4")
        .arg(socket.localAddress().toString()).arg(socket.localPort())
        .arg(socket.peerAddress().toString()).arg(socket.peerPort());
}

void ClientConnection::send(const protocol::Packet &packet)
{
    if (!canSend())
        return;

    const auto call = m_session->replica->exchange(protocol::encode(packet));
    m_pending = new QRemoteObjectPendingCallWatcher(call, m_session);
    connect(m_pending, &QRemoteObjectPendingCallWatcher::finished, this, &ClientConnection::finishReply);

    m_replyTimer.start();
    emit packetSent(packet);
    emit changed();
}

void ClientConnection::connectTcp()
{
    auto *session = new Session(this);
    m_session = session;
    auto *socket = &session->socket;

    connect(socket, &QTcpSocket::connected, this, [this, session, socket] {
        socket->setSocketOption(QAbstractSocket::KeepAliveOption, 1);
        setStatus(tr("TCP подключён. Инициализация Qt Remote Objects…"));
        if (m_session == session)
            session->node.addClientSideConnection(socket);
    });
    connect(socket, &QTcpSocket::errorOccurred, this, [this, socket] {
        fail(tr("Ошибка TCP: %1").arg(socket->errorString()));
    });
    connect(socket, &QTcpSocket::disconnected, this, [this] {
        fail(tr("Соединение TCP закрыто"));
    });
    connect(session->replica.get(), &QRemoteObjectReplica::stateChanged, this,
            [this](QRemoteObjectReplica::State state, QRemoteObjectReplica::State previous) {
                if (state == QRemoteObjectReplica::Valid) {
                    m_connectTimer.stop();
                    emit logMessage(connectionDetails());
                    setStatus(tr("Подключён · PacketExchange готов"));
                } else if (state == QRemoteObjectReplica::SignatureMismatch) {
                    fail(tr("Интерфейс PacketExchange не совпадает с сервером"));
                } else if (previous == QRemoteObjectReplica::Valid) {
                    fail(tr("Объект PacketExchange больше недоступен"));
                }
            });

    m_connectTimer.start();
    setStatus(tr("Подключение к [%1]:%2…").arg(m_host).arg(m_port));
    if (m_session == session)
        socket->connectToHost(m_host, m_port);
}

void ClientConnection::closeSession()
{
    m_connectTimer.stop();
    m_replyTimer.stop();
    if (!m_session)
        return;

    if (m_pending) {
        disconnect(m_pending, nullptr, this, nullptr);
        m_pending = nullptr;
    }

    auto *session = m_session;
    m_session = nullptr;
    disconnect(&session->socket, nullptr, this, nullptr);
    disconnect(session->replica.get(), nullptr, this, nullptr);
    session->socket.abort();
    // Socket and replica signals can be on the stack when a session fails.
    session->deleteLater();
}

void ClientConnection::fail(const QString &reason)
{
    if (m_autoReconnect)
        m_retryTimer.start();
    disconnectSession(reason);
}

void ClientConnection::disconnectSession(const QString &reason)
{
    const bool replyPending = m_pending != nullptr;
    closeSession();

    if (m_retryTimer.isActive())
        setStatus(tr("%1. Повтор через %2 с").arg(reason).arg(retryIntervalMs / 1000));
    else
        setStatus(reason);

    if (replyPending)
        emit logMessage(tr("Ответ на отправленный пакет не получен"));
    emit logMessage(reason);
}

void ClientConnection::finishReply(QRemoteObjectPendingCallWatcher *reply)
{
    m_pending = nullptr;
    m_replyTimer.stop();
    reply->deleteLater();

    if (reply->error() != QRemoteObjectPendingCall::NoError) {
        emit logMessage(tr("Ошибка удалённого вызова (код %1)").arg(int(reply->error())));
    } else if (const auto packet = protocol::decode(reply->returnValue().toByteArray())) {
        emit packetReceived(*packet);
    } else {
        emit logMessage(tr("Сервер вернул пакет неверной длины"));
    }

    emit changed();
}

void ClientConnection::setStatus(const QString &status)
{
    m_status = status;
    emit changed();
}
