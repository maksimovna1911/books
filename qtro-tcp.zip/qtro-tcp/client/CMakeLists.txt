cmake_minimum_required(VERSION 3.22)

project(QtRoClient LANGUAGES CXX)

find_package(Qt6 6.10 REQUIRED COMPONENTS Widgets Network RemoteObjects)
qt_standard_project_setup()

qt_add_executable(QtRoClient WIN32 main.cpp clientpanel.cpp clientpanel.h)
set_target_properties(QtRoClient PROPERTIES
    CXX_STANDARD 23
    CXX_STANDARD_REQUIRED ON
    CXX_EXTENSIONS OFF
)
target_include_directories(QtRoClient PRIVATE ../protocol "${CMAKE_CURRENT_BINARY_DIR}")
target_link_libraries(QtRoClient PRIVATE Qt6::Widgets Qt6::Network Qt6::RemoteObjects)
qt_add_repc_replicas(QtRoClient ../protocol/PacketExchange.rep)
