#pragma once

#include "packet.h"

#include <QGroupBox>

#include <memory>

namespace Ui {
class PacketEditor;
}

class PacketEditor final : public QGroupBox
{
    Q_OBJECT

public:
    explicit PacketEditor(QWidget *parent = nullptr);
    ~PacketEditor() override;

    protocol::Packet packet() const;

private:
    std::unique_ptr<Ui::PacketEditor> m_ui;
};
