#pragma once

#include "packet.h"

#include <QGroupBox>
#include <QTimer>

#include <array>

class QCheckBox;
class QLabel;
class QLineEdit;
class QPlainTextEdit;
class QPushButton;
class QRemoteObjectPendingCallWatcher;
class QSpinBox;

class ClientPanel final : public QGroupBox
{
    Q_OBJECT

public:
    ClientPanel(const QString &title, quint16 port, QWidget *parent = nullptr);
    ~ClientPanel() override;

    void start();

private:
    struct Connection;

    void connectTcp();
    void closeConnection();
    void connectionFailed(const QString &reason);
    void sendPacket();
    void updateControls();
    void appendLog(const QString &message);

    Connection *m_connection = nullptr;
    QRemoteObjectPendingCallWatcher *m_pending = nullptr;
    QTimer m_retryTimer;
    QTimer m_connectionTimer;
    QTimer m_replyTimer;
    bool m_running = false;

    QLineEdit *m_host;
    QSpinBox *m_port;
    QCheckBox *m_autoReconnect;
    QPushButton *m_connectButton;
    QLabel *m_status;
    QLabel *m_endpoints;
    QSpinBox *m_reqWord;
    QSpinBox *m_respWord;
    std::array<QSpinBox *, protocol::dataWordCount> m_data;
    QPushButton *m_sendButton;
    QPlainTextEdit *m_log;
};
