#pragma once

#include "clientconnection.h"

#include <QGroupBox>

#include <memory>

namespace Ui {
class ClientPanel;
}

class ClientPanel final : public QGroupBox
{
    Q_OBJECT

public:
    explicit ClientPanel(QWidget *parent = nullptr);
    ~ClientPanel() override;

    void setPort(quint16 port);
    void start();

private:
    void refresh();
    void appendLog(const QString &message);

    std::unique_ptr<Ui::ClientPanel> m_ui;
    ClientConnection m_connection;
};
